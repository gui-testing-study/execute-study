# Cytestion

Is an exhaustive/exploratory end-to-end and GUI testing tool for web applications and uses
the [cypress](https://www.cypress.io/) framework to do so.
During its execution, Cytestion dinamically scans the html code of the current page in your web application, identifies interactable
elements and generate cypress test cases that are then executed in search of system failures. Simple as that!

## Get started!

To start using Cytestion, it is necessary to follow some steps to ensure that everything will work correctly.
Don't worry, it'll not take much of your time.

### Requirements

The requirements Cytestion needs to work properly are:

* **Linux** based operating system.
* [NodeJS](https://nodejs.org/en) and [Yarn](https://yarnpkg.com/) package manager;
* It is mandatory that you add **data-cy**, **dataCy** or **datacy** attribute to any components that you want to be
  seen by Cytestion.

### Executing Cytestion

First, you need to install all project dependencies. This can be achieved by running the following command:

```sh
yarn install
```

Cytestion uses [Dotenv](https://www.npmjs.com/package/dotenv) to read environment variables provided in a **.env** file,
so you must create such file and provide
the needed environment variables. Your **.env** file should look like this:

```properties
BASE_URL=<url to app in production>           # https://www.example.com
BASE_URL_API=<url to app api in production>   # https://www.example.com/api
LOGIN_URL=<login url to app in production>    # https://www.example.com/login
USER_LOGIN=<user login>                       # user.login
USER_PASSWORD=<user password>                 # 123safePass123
```

Your can also add optional variables to get some extra configurations:

```properties
BROWSER=<which browser your application will be accessed and interacted with>       # chrome, chromium or firefox
E2E_FOLDER=<intended location for test files>                                       # ../e2e/test/folder/hooray
FIXTURES_FOLDER=<intended location for fixtures files used in tests>                # cypress/fixtures
ALLOWABLE_CODE_ERROR=<error codes that will not fail the tests case>                # 406
CHECK_400=<whether test case fails when error codes of 400 family are captured>     # true
CHECK_500=<whether test case fails when error codes of 500 family are captured>     # false
ERROR_MESSAGE=<error messages that appear in the GUI cause the test case to fail>   # Unexpected Error,Exception
```

After your **.env** is ready and set, it is time to run Cytestion. Just like all the other steps, this one is very
simple!

```sh
yarn generate-test:prod
```

## Important!

* In the first run, it will be necessary to inform the **baseUrl** and **baseUrlApi** that will be placed in the cypress
  configuration file;
* The generated artifact will be a test file called `cytestion.spec.js`, which will be place in the default or
  provided `E2E_FOLDER`;
* With the use of the optional variable `BROWSER`, it is necessary to install said browser on the host machine;
* The `ALLOWABLE_CODE_ERROR` env lets you provide an error code your application may throw. The test executions will
  not fail when this code is captured by Cypress. 

### Details

The test generation process starts with an initial visit to the provided base url, after that, the html found on the
page is analyzed and, selectively, new tests are created, from the identifiers `['data-cy=', 'dataCy=', 'datacy=']`
found.
The final objective is to go through all possible paths by means of clicking on buttons and filling and submitting all
the forms that were encontered during the analysis.

## Running test files

Running test files is simple, you will just have to make sure your envs are all correct.
It is very important that you inform the location of your tests as the `E2E_FOLDER` variable.

After that, you just need to run the following commands in your project folder.

```sh
yarn setup-cypress
```
```sh
yarn cypress
```

If everything went well, you should be seeing a screen portraying the contents of your `E2E_FOLDER`, 
and upon selecting a test file, congratulations, your tests are running!
