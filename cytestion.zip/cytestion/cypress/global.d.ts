/// <reference types="cypress" />

declare namespace Cypress {
  interface Cypress {
    /**
     * The API hosts which cypress will monitor, it supports multiple host strings separated by comma.
     */
    env(key: 'apiHosts'): string;
  }

  interface Chainable {
    /**
     * Data store for the test case
     */
    _data: {
      decoyRequestTimeout: NodeJS.Timeout;
      pendingAPICount: number;
      errorsDetected: number;
      window: any;
    };
  }
}
