import { hashCode } from './utils/utils';
import 'cypress-wait-until';
import dayjs from 'dayjs';

Cypress.Commands.add('writeContent', (actualId) => {
  const actualIdName = actualId.join('->');
  const actualIdHashCoded = hashCode(actualIdName);
  cy.url().then((url) => {
    cy.window().then((win) => {
      cy.task('writeFile', {
        filePath: `tmp/${actualIdHashCoded}`,
        data: `$$${url}$$ ${win.document.body.outerHTML}`,
      });
    });
  });
  cy.readFile('tmp/translate.json').then((obj) => {
    obj[actualIdHashCoded] = actualIdName;
    cy.task('writeFile', {
      filePath: 'tmp/translate.json',
      data: JSON.stringify(obj),
    });
  });
});

Cypress.Commands.add('actionability', ($id) => {
  cy.window().then((win) => {
    const elementFromView = Cypress.dom.getElementAtPointFromViewport(win.document, $id[0].getBoundingClientRect().x, $id[0].getBoundingClientRect().y);
    if (!elementFromView) return false;
    return elementFromView.contains($id[0]) || elementFromView.parentNode === $id[0] || $id[0].contains(elementFromView);
  });
});

Cypress.Commands.add('clearThenType', { prevSubject: true }, (subject, text) => {
  cy.wrap(subject).clear().type(text);
});

Cypress.Commands.add('mouseOutIfExist', (element) => {
  cy.wait(200);
  cy.get('body').then((body) => {
    if (body.find(element).length > 0) {
      cy.get(element).each(($el) => cy.wrap($el).trigger('mouseout', { force: true }));
    }
  });
});

Cypress.Commands.add('clickIfExist', (element) => {
  cy.get('body').then((body) => {
    if (body.find(element).length > 0) {
      cy.get(element)
        .first()
        .scrollIntoView()
        .then(($id) => {
          cy.actionability($id).then((actionable) => {
            const tagA = Cypress.$($id).find('a').attr('target');
            const isNewTab = tagA && tagA === '_blank';
            if (actionable && $id.is(':visible') && !$id.is(':disabled') && !isNewTab) {
              $id.prevObject?.length > 1 ? cy.get(element).first().click({ force: true }) : cy.wrap($id).click();
              cy.mouseOutIfExist('.ant-tooltip-open');
              cy.wait(200);
            }
          });
        });
    }
  });
});

Cypress.Commands.add('clickCauseExist', (element) => {
  cy.get(element)
    .first()
    .scrollIntoView()
    .then(($id) => {
      cy.actionability($id).then((actionable) => {
        if (actionable && $id.is(':visible') && !$id.is(':disabled')) {
          $id.prevObject?.length > 1 ? cy.get(element).first().click({ force: true }) : cy.wrap($id).click();
          cy.mouseOutIfExist('.ant-tooltip-open');
          cy.wait(200);
        }
      });
    });
});

/*unused function - actual version of cytestion doesn't click by classes*/
Cypress.Commands.add('clickIfExistClass', (element) => {
  cy.get('body').then((body) => {
    if (body.find(element).length > 0) {
      cy.get(element).first().scrollIntoView().click({ force: true });
      cy.wait(200);
    }
  });
});

Cypress.Commands.add('fillInput', (element, value) => {
  cy.get('body').then((body) => {
    if (body.find(element).length > 0) {
      cy.get(element)
        .first()
        .scrollIntoView()
        .then(($id) => {
          cy.actionability($id).then((actionable) => {
            if (actionable && $id.is(':visible') && !$id.is(':disabled')) {
              cy.get(element).first().click({ force: true }).clearThenType(value);
            }
          });
        });
    }
  });
});

Cypress.Commands.add('fillInputSelect', (element) => {
  cy.get('body').then((body) => {
    if (body.find(element).length > 0) {
      cy.get(element)
        .first()
        .scrollIntoView()
        .then(($id) => {
          cy.actionability($id).then((actionable) => {
            if (actionable && !$id.is(':disabled')) {
              cy.get(element).first().trigger('click').wait(50).type('{downarrow}').type('{enter}');
            }
          });
        });
    }
  });
});

Cypress.Commands.add('fillInputPowerSelect', (element, tries = ['a', 'e', '1']) => {
  if (!Array.isArray(tries)) tries = [tries];
  const fillInputPowerSelectRecursive = (element, tries) => {
    cy.get('body').then((body) => {
      if (body.find(element).length > 0) {
        cy.get(element)
          .first()
          .scrollIntoView()
          .then(($id) => {
            cy.actionability($id).then((actionable) => {
              if (actionable && $id.is(':visible') && !$id.is(':disabled') && tries.length > 0) {
                cy.get(element).first().click({ force: true }).wait(200).clearThenType(tries[0]).wait(1000);
                cy.wait(200);
                cy.get(element)
                  .first()
                  .click({ force: true })
                  .type('{downarrow}')
                  .type('{enter}')
                  .wait(200)
                  .invoke('attr', 'aria-activedescendant')
                  .then((value) => {
                    if (value.includes('list_-1')) fillInputPowerSelectRecursive(element, tries.splice(1, tries.length));
                  });
              }
            });
          });
      }
    });
  };
  fillInputPowerSelectRecursive(element, tries);
});

Cypress.Commands.add('fillInputDate', (element, type, dateString) => {
  const format = type === 'month' ? 'MM/YYYY' : 'DD/MM/YYYY';
  const date = dateString ? dayjs(dateString).format(format) : dayjs();
  cy.get('body').then((body) => {
    if (body.find(element).length > 0) {
      cy.get(element)
        .first()
        .scrollIntoView()
        .then(($id) => {
          cy.actionability($id).then((actionable) => {
            if (actionable && $id.is(':visible') && !$id.is(':disabled')) {
              if (type !== 'range') {
                cy.get(element).first().click({ force: true }).clear().type(date.format(format)).type('{enter}');
              } else {
                cy.get(element).first().click({ force: true }).clear().type(date.format(format)).type('{enter}');
                cy.get(element).last().click({ force: true }).clear().type(date.add('days', 1).format(format)).type('{enter}');
              }
            }
          });
        });
    }
  });
});

Cypress.Commands.add('fillInputCheckboxOrRadio', (element) => {
  cy.get('body').then((body) => {
    if (body.find(element).length > 0) {
      cy.get(element)
        .first()
        .scrollIntoView()
        .then(($id) => {
          cy.actionability($id).then((actionable) => {
            if (actionable && !$id.is(':disabled')) {
              cy.get(element).first().click({ force: true });
            }
          });
        });
    }
  });
});

Cypress.Commands.add('submitIfExist', (element) => {
  cy.get('body').then((body) => {
    if (body.find(element).length > 0) {
      cy.get(element).first().submit().wait(200);
      cy.wait(200);
    }
  });
});

Cypress.Commands.add('waitUntilAllAPIFinished', () => {
  cy.wait(500);
  cy.get('body', { timeout: 60 * 1000, log: false }).should(() => {
    expect(cy._data.pendingAPICount, 'Waiting for pending API requests').to.eq(0);
  });
  let intervalCounter = 0;
  cy.waitUntil(() => ++intervalCounter === 60 || cy._data.window.document.body.outerHTML.includes('data-cy='), {
    timeout: 60000,
    interval: 1000,
  });
  cy.wait(500);
});

Cypress.Commands.add('checkErrorsWereDetected', () => {
  cy.get('body').should(() => {
    expect(cy._data.errorsDetected, 'Check errors were detected').to.eq(0);
  });
  const errorMessage = Cypress.env('errorMessage');
  const check400 = Cypress.env('check400');
  const check500 = Cypress.env('check500');
  let allowableCodeError = Cypress.env('allowableCodeError');
  allowableCodeError = parseInt(allowableCodeError);
  if (errorMessage) {
    const errorMessageSplitted = errorMessage.split(',');
    errorMessageSplitted.forEach((message) => {
      cy.get('body', { timeout: 500 }).should('not.contain', message);
    });
  }
  const checkRequestErrorRecursive = (aliases) => {
    if (aliases.length > 0) {
      cy.get(aliases[0]).then((alias) => {
        if (alias)
          cy.get(`${aliases[0]}.all`).each(($al) =>
            cy
              .wrap($al)
              .its('response')
              .should((response) => {
                if (response) {
                  const { statusCode } = response;
                  if (statusCode) {
                    if (check500) {
                      expect(statusCode, 'Check requests with server error').be.lt(500);
                    }
                    if (check400) {
                      const conditionAllowableFunc = (code) => (allowableCodeError ? code === allowableCodeError : false);
                      expect(statusCode, 'Check requests with client error').to.satisfy((code) => {
                        return code < 400 || conditionAllowableFunc(code) || code >= 500;
                      });
                    }
                  }
                }
              })
          );
        checkRequestErrorRecursive(aliases.splice(1, aliases.length));
      });
    }
  };
  checkRequestErrorRecursive(['@getRequest', '@postRequest', '@putRequest', '@patchRequest', '@deleteRequest']);
});
