import './commands';
import './test-setup';
import './custom-commands';
import 'cypress-failed-log';
import { plantWaitUntilSomeRequestOccurs } from './utils/auto-stub';

const resizeObserverLoopErrRe = /^[^(ResizeObserver loop limit exceeded)]/;
const uncaughtError = /Uncaught: /;
const typeErrorError = /TypeError: /;

Cypress.on('uncaught:exception', (err) => {
  /* returning false here prevents Cypress from failing the test */
  if (resizeObserverLoopErrRe.test(err.message)) {
    return false;
  }
});

Cypress.on('window:before:load', (win) => {
  cy.stub(win.console, 'error', (msg) => {
    if (uncaughtError.test(msg) || typeErrorError.test(msg)) {
      cy._data.errorsDetected += 1;
      cy.task('error', msg);
      throw new Error(msg);
    }
  }).as('consoleError');
  cy.stub(win, 'open')
    .callsFake((url) => win.open.wrappedMethod.call(win, url, '_self'))
    .as('windowOpen');
  cy.stub(win, 'print')
    .callsFake((url) => win.open.wrappedMethod.call(win, url, '_self'))
    .as('windowPrint');
});

Cypress.on('url:changed', (newUrl) => {
  plantWaitUntilSomeRequestOccurs();
  console.log('newUrl', newUrl);
});
