import { setupCypressInterception } from './utils/auto-stub';

before(() => {
  cy._data = {};
});

beforeEach(() => {
  setupCypressInterception();
});
