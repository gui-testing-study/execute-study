import { CyHttpMessages } from 'cypress/types/net-stubbing';

function increaseAPICountOnRequestStart() {
  cy._data.pendingAPICount += 1;
}

function decreaseAPICountOnRequestFinish() {
  if (cy._data.decoyRequestTimeout) {
    clearTimeout(cy._data.decoyRequestTimeout);
    cy._data.decoyRequestTimeout = undefined;
    subtractPendingAPICount();
  }
  const delayTime = 500;
  if (cy._data.pendingAPICount === 1) {
    setTimeout(() => {
      subtractPendingAPICount();
    }, delayTime);
  } else {
    subtractPendingAPICount();
  }
}

function subtractPendingAPICount() {
  if (cy._data.pendingAPICount > 0) cy._data.pendingAPICount -= 1;
}

function routeHandlerWithRealResponse(
  request: CyHttpMessages.IncomingHttpRequest
) {
  increaseAPICountOnRequestStart();
  request.reply((response) => {
    handlerResponseWithFile(response);
    response.send();
    decreaseAPICountOnRequestFinish();
  })
}

function handlerResponseWithFile({ headers }) {
  const includesAttachment = headers['content-disposition']?.includes('attachment');
  const includesOctetStream = headers['content-type']?.includes('application/octet-stream');
  if (includesAttachment || includesOctetStream) {
    setTimeout(function () { cy._data.window.document.location?.reload() }, 5000);
  };
}

export function plantWaitUntilSomeRequestOccurs() {
  cy._data.pendingAPICount = 1;
  cy._data.decoyRequestTimeout = setTimeout(() => {
    cy._data.decoyRequestTimeout = undefined;
    subtractPendingAPICount();
  }, 5000);
}

export function setupCypressInterception() {
  cy.window().then(window => {
    cy._data.decoyRequestTimeout = undefined;
    cy._data.pendingAPICount = 0;
    cy._data.errorsDetected = 0;
    cy._data.window = window;
    startMonitorAPI();
  });
}

function startMonitorAPI() {
  const apiHosts = Cypress.env('apiHosts').split(',');
  apiHosts.forEach((pattern: string) => {
    const apiRegex = new RegExp(pattern.trim());
    cy.intercept('GET', apiRegex, routeHandlerWithRealResponse).as('getRequest');
    cy.intercept('POST', apiRegex, routeHandlerWithRealResponse).as('postRequest');
    cy.intercept('PUT', apiRegex, routeHandlerWithRealResponse).as('putRequest');
    cy.intercept('PATCH', apiRegex, routeHandlerWithRealResponse).as('patchRequest');
    cy.intercept('DELETE', apiRegex, routeHandlerWithRealResponse).as('deleteRequest');
  });
}