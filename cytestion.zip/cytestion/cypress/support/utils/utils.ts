export function hashCode(value){
  let hash = 0,
    i = 0,
    len = value?.length || 0;
  while (i < len) {
    hash = ((hash << 5) - hash + value.charCodeAt(i++)) << 0;
  }
  return hash + 2147483647 + 1;
};