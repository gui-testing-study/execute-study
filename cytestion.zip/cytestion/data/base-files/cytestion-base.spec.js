describe('Automatic generated test file to click on elements on the page', () => {
  beforeEach(() => {
    cy.visit('/');
    cy.wait(200);
  });
  //--CODE--
  it(`Visits index page`, () => {
    const actualId = [`root`];
    cy.checkErrorsWereDetected();
    cy.writeContent(actualId);
  });
  //--CODE--
});
