require('dotenv').config();
const fs = require('fs');
const spawn = require('cross-spawn');
const { execSync } = require('child_process');
const executionMode = process.env.EXECUTION_MODE;
const nodeEnv = process.env.NODE_ENV;
const browser = process.env.BROWSER;
const baseUrl = process.env.BASE_URL;
const baseUrlApi = process.env.BASE_URL_API;
const loginUrl = process.env.LOGIN_URL;
const userLogin = process.env.USER_LOGIN;
const userPassword = process.env.USER_PASSWORD;
const keycloakUrl = process.env.KEYCLOAK_URL;
const clientSecret = process.env.CLIENT_SECRET;

const e2eFolder = process.env.E2E_FOLDER || '../e2e/exploratory';
const fixturesFolder = process.env.FIXTURES_FOLDER;

const errorMessage = process.env.ERROR_MESSAGE;
const check500 = process.env.CHECK_500;
const check400 = process.env.CHECK_400;
const allowableCodeError = process.env.ALLOWABLE_CODE_ERROR;
let currentStage;

/**
 * Stage 1 - Verifying existence of cypress config file and set environment variables.
 *
 * Create cypress config file if it does not exist.
 */
const verifyOrCreateDirectoryAndUtilFiles = () => {
  if (!checkCorrectStage(1)) return;

  const configFileExists = fs.existsSync('cypress.json') && Object.keys(JSON.parse(fs.readFileSync('cypress.json'))).includes('baseUrl');
  const createConfigFile = () => {
    const configFile = {
      // retries: 2,
      integrationFolder: e2eFolder,
      requestTimeout: 10000,
      defaultCommandTimeout: 5000,
      viewportWidth: 1280,
      viewportHeight: 720,
      numTestsKeptInMemory: 0,
      chromeWebSecurity: false,
      failOnStatusCode: false,
      // video: false,
    };
    configFile.baseUrl = baseUrl;
    configFile.env = {};
    configFile.env.apiHosts = baseUrlApi;
    configFile.env.baseUrl = baseUrl;
    if (fixturesFolder) {
      configFile.fixturesFolder = fixturesFolder;
      configFile.env.fixturesFolder = fixturesFolder;
    }
    if (loginUrl && userLogin && userPassword) {
      configFile.env.loginUrl = loginUrl;
      configFile.env.userLogin = userLogin;
      configFile.env.userPassword = userPassword;
    }
    if (keycloakUrl && clientSecret && userLogin && userPassword) {
      configFile.env.keycloakUrl = keycloakUrl;
      configFile.env.userLogin = userLogin;
      configFile.env.userPassword = userPassword;
      configFile.env.clientSecret = clientSecret;
    }
    if (errorMessage) configFile.env.errorMessage = errorMessage;
    if (check500) configFile.env.check500 = check500;
    if (check400) configFile.env.check400 = check400;
    if (allowableCodeError) configFile.env.allowableCodeError = allowableCodeError;

    fs.writeFileSync('cypress.json', JSON.stringify(configFile));
    execSync(`yarn format-file cypress.json`, { stdio: 'pipe' });
    if (nodeEnv !== 'setup') goToNextStage();
  };
  if (baseUrl && baseUrlApi && e2eFolder) {
    createConfigFile();
  } else if (!configFileExists) {
    console.log('Environment variables have not been passed. Furthermore, cypress.json file does not exist or does not contain baseUrl property. Finishing the execution.');
    process.exit(1);
  } else if (nodeEnv !== 'setup') goToNextStage();
  process.exit(0);
};

/**
 * Stage 2 - Checks if the tests have already been generated, inform it will be replaced.
 *
 * Check existence of file with exploratory tests and clear tmp directory.
 */
const checkTestsAlreadyGenerate = () => {
  if (!checkCorrectStage(2)) return;

  const logsDir = 'cypress/logs';
  const fileTestName = 'cytestion.spec.js';
  const fileTest = `${e2eFolder}/${fileTestName}`;
  const fileTestTmp = `${e2eFolder}/tmp/${fileTestName}`;
  const filesTmp = fs.readdirSync('tmp/').filter((file) => file !== '.gitignore');

  if (fs.existsSync(fileTestTmp)) execSync(`rm -R ${e2eFolder}/tmp`);
  if (filesTmp.length > 0) execSync(`rm -v tmp/*`);
  if (fs.existsSync(logsDir)) execSync(`rm -R ${logsDir}`);
  if (fs.existsSync(fileTest) && nodeEnv === 'generation') infoPrettyPrint('Important! File with exploratory tests was found. After this execution it will be replaced.');

  goToNextStage();
};

/**
 * Stage 3 - Generating tests
 *
 * Exec yarn command for tests generation
 */
const generateTests = () => {
  if (!checkCorrectStage(3)) return;

  let count = 0;
  let status = 0;
  const fileTestName = 'cytestion.spec.js';
  const fileTest = `${e2eFolder}/tmp/${fileTestName}`;
  const options = ['test-file', fileTest, '-c', 'video=false'];
  if (browser) {
    options.push('--browser');
    options.push(browser);
  }
  const execFileTest = () => {
    const execution = spawn.sync('yarn', options, {
      stdio: 'inherit',
    });
    if (execution.status !== 0) status = execution.status;
  };

  execSync('yarn start-generate');
  do {
    execFileTest();
    createVisualizationFiles(count++);
    execSync('yarn start-generate');
  } while (fs.readdirSync('tmp/').filter((file) => file !== '.gitignore').length > 0);
  console.log(`Test file generated! (${e2eFolder}/${fileTestName})`);
  console.timeEnd('Time execution');

  const logsDir = 'cypress/logs';
  if (fs.existsSync(logsDir)) goToNextStage();
  process.exit(status);
};

const createVisualizationFiles = (count) => {
  execSync(`mkdir -p ${e2eFolder}/visualization`);
  execSync(`cp tmp/translate.json ${e2eFolder}/visualization/system-map-${count}.json`);
};

/**
 * Stage 4 - Run Regression Tests
 *
 * Exec yarn command for run regression generation
 */
const runRegressionTests = () => {
  if (!checkCorrectStage(4)) return;

  const fileTest = `${e2eFolder}/cytestion.spec.js`;
  if (!fs.existsSync(fileTest)) {
    console.log(`No test file found to run.`);
    process.exit(0);
  }

  const options = ['test-file', fileTest];
  if (browser) {
    options.push('--browser');
    options.push(browser);
  }
  const execution = spawn.sync('yarn', options, {
    stdio: 'inherit',
  });

  console.log(`Regression Test Performed! (${fileTest})`);
  console.timeEnd('Time execution');

  const logsDir = 'cypress/logs';
  if (fs.existsSync(logsDir)) goToNextStage();
  process.exit(execution.status);
};

/**
 * Stage 5 - Run Failures Tests
 *
 * Exec yarn command for run failues tests
 */
const runFailuresTests = () => {
  if (!checkCorrectStage(5)) return;

  // console.time('Time execution');
  createFileTestFailures();
  process.exit(1);
  execSync(`rm -r cypress/logs`);
  const fileTestFailures = `${e2eFolder}/cytestion.failures.spec.js`;

  if (fs.existsSync(fileTestFailures)) {
    const options = ['test-file', fileTestFailures, '-c', 'video=false'];
    if (browser) {
      options.push('--browser');
      options.push(browser);
    }
    const execution = spawn.sync('yarn', options, {
      stdio: 'inherit',
    });

    console.log(`Failures Test Performed! (${fileTestFailures})`);
    console.timeEnd('Time execution');
    createFileTestFailures();
    process.exit(execution.status);
  }
  process.exit(1);
};

const createFileTestFailures = () => {
  const logsDir = 'cypress/logs';
  if (fs.existsSync(logsDir)) {
    const filesLogs = fs.readdirSync(logsDir);
    const testTitles = filesLogs.map((file) => JSON.parse(fs.readFileSync(`${logsDir}/${file}`))?.title);

    const fileTest = fs.readFileSync(`${e2eFolder}/cytestion.spec.js`).toString();
    const tests = fileTest.split(' it(');
    const header = tests.shift();
    const result = [header];
    tests.forEach((test) => testTitles.some((title) => test.includes(title)) && result.push(test));
    if (result.length === 1) {
      console.log('Could not find the tests that failed.');
      process.exit(1);
    }
    let fileTestFailures = result.join(' it(');
    if (!(tests[tests.length - 1] === result[result.length - 1])) fileTestFailures += '\n});';
    fs.writeFileSync(`${e2eFolder}/cytestion.failures.spec.js`, fileTestFailures);
    execSync(`yarn format-file ${e2eFolder}/cytestion.failures.spec.js`, { stdio: 'pipe' });
    if (result.length / tests.length > 0.5) {
      console.log('More than 50% of existing tests have failed. Re-execution is very costly. Finishing.');
      process.exit(1);
    }
  }
};

const printPrettyWelcome = () => {
  console.time('Time execution');
  console.info('\033[1;92mWelcome to Cytestion!\033[0;0m ' + 'Automatic exploratory testing code generator, using the cypress framework');
};

const infoPrettyPrint = (message) => {
  console.info('\033[1;92mINFO:\033[0;0m ' + message);
};

const checkCorrectStage = (stageNumber) => {
  return currentStage.id === stageNumber;
};

const setStage = (stageNumber) => {
  currentStage = stages.find((stage) => stage.id === stageNumber);

  infoPrettyPrint(`${currentStage.name}`);
};

const goToNextStage = () => {
  let nextStageNumber;
  if (currentStage.id === 2 && nodeEnv === 'regression') {
    nextStageNumber = currentStage.id + 2;
  } else if (currentStage.id === 3 && nodeEnv === 'generation') {
    nextStageNumber = currentStage.id + 2;
  } else {
    nextStageNumber = currentStage.id + 1;
  }
  setStage(nextStageNumber);
  currentStage = stages.find((stage) => stage.id === nextStageNumber);

  currentStage.func();
};

const checkEnvironmentVariables = () => {
  if (!nodeEnv) {
    console.log('NODE_ENV variable not found.');
    process.exit(1);
  } else if (executionMode === 'production') {
    if (!baseUrl || !baseUrlApi || !userLogin || !userPassword || (!loginUrl && (!keycloakUrl || !clientSecret))) {
      console.log('It is necessary to pass all the environment variables to run in production mode.');
      process.exit(1);
    }
  } else if (executionMode === 'development') {
    if (!baseUrl || !baseUrlApi) {
      console.log('It is necessary to pass BASE_URL and BASE_URL_API environment variables to run in development mode.');
      process.exit(1);
    }
  }
  printEnvironmentVariables();
};

const printEnvironmentVariables = () => {
  if (executionMode) console.log('EXECUTION_MODE=' + executionMode);
  console.log('NODE_ENV=' + nodeEnv);
  if (browser) console.log('BROWSER=' + browser);
  console.log('BASE_URL=' + baseUrl);
  console.log('BASE_URL_API=' + baseUrlApi);
  console.log('USER_LOGIN=' + userLogin);
  console.log('USER_PASSWORD=' + userPassword);
  if (loginUrl) console.log('LOGIN_URL=' + loginUrl);
  if (keycloakUrl) console.log('KEYCLOAK_URL=' + keycloakUrl);
  if (clientSecret) console.log('CLIENT_SECRET=**********');
  console.log('E2E_FOLDER=' + e2eFolder);
  if (fixturesFolder) console.log('FIXTURES_FOLDER=' + fixturesFolder);
  if (errorMessage) console.log('ERROR_MESSAGE=' + errorMessage);
  if (check400) console.log('CHECK_400=' + check400);
  if (check500) console.log('CHECK_500=' + check500);
  if (allowableCodeError) console.log('ALLOWABLE_CODE_ERROR=' + allowableCodeError);
};

const stages = [
  {
    id: 1,
    name: 'Verifying existence of cypress config file and set environment variables',
    func: verifyOrCreateDirectoryAndUtilFiles,
  },
  {
    id: 2,
    name: 'Checks if the tests have already been generated, inform it will be replaced.',
    func: checkTestsAlreadyGenerate,
  },
  {
    id: 3,
    name: 'Generating Tests',
    func: generateTests,
  },
  {
    id: 4,
    name: 'Run Regression Tests',
    func: runRegressionTests,
  },
  {
    id: 5,
    name: 'Run Failures Tests',
    func: runFailuresTests,
  },
];

checkEnvironmentVariables();
printPrettyWelcome();
setStage(1);
verifyOrCreateDirectoryAndUtilFiles();
