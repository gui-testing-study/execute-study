const util = require('./util');
const faker = require('faker-br');

const generateNewTestCodes = (code, actualFile, codes, newCodes) => {
  actualFile.idClick.length > 0 && generateIdClick(code, actualFile.idClick, codes, newCodes);
  actualFile.classClick.length > 0 && generateClassClick(code, actualFile.classClick, codes, newCodes);
  actualFile.idsForm.length > 0 && generateIdsForm(code, actualFile.idsForm, codes, newCodes);
};

const generateIdClick = (code, idList, codes, newCodes) => {
  idList.forEach((elem) => {
    const treatedId = [...code.actualId, elem.id.split('/').join('-')];
    const actualString = `const actualId = [${'`' + treatedId.join('`,`') + '`'}];`;
    if (util.willNotGenerateDuplicate(actualString, elem.id.split('/').join('-'), codes, newCodes)) {
      let newCode = putIdClickSnippet(code.codeText, elem.id, elem.typeId);
      newCode = newCode.replace(/^.*const actualId = .*$/gm, actualString);

      newCode = newCode.replace(util.getContentBetween(newCode, 'it(`', '`,'), `Click on element ${treatedId.join('->')}`);

      newCodes.push(newCode);
    }
  });
};

const generateClassClick = (code, classList, codes, newCodes) => {
  classList.forEach((elem) => {
    const treatedId = [...code.actualId, elem.id.split('/').join('-')];
    const actualString = `const actualId = [${'`' + treatedId.join('`,`') + '`'}];`;
    if (util.willNotGenerateDuplicate(actualString, elem.id.split('/').join('-'), codes, newCodes)) {
      let newCode = putClassClickSnippet(code.codeText, elem.id, elem.typeId);
      newCode = newCode.replace(/^.*const actualId = .*$/gm, actualString);

      newCode = newCode.replace(util.getContentBetween(newCode, 'it(`', '`,'), `Click on element ${treatedId.join('->')}`);

      newCodes.push(newCode);
    }
  });
};
const generateIdsForm = (code, idsForm, codes, newCodes) => {
  const listOnlyId = idsForm.map((elem) => elem.id);
  const treatedId = [...code.actualId, listOnlyId.join('-').split('/').join('-')];
  const actualString = `const actualId = [${'`' + treatedId.join('`,`') + '`'}];`;
  if (util.willNotGenerateDuplicate(actualString, listOnlyId.join('-').split('/').join('-'), codes, newCodes)) {
    let newCode = putIdFormSnippet(code.codeText, idsForm);
    newCode = newCode.replace(/^.*const actualId = .*$/gm, actualString);

    newCode = newCode.replace(util.getContentBetween(newCode, 'it(`', '`,'), `Filling values ${treatedId.join('->')} and submit`);

    newCodes.push(newCode);
  }
};

const putIdClickSnippet = (codeText, id, typeId) => {
  const clickCode = `cy.clickIfExist(\`[${typeId}"${id}"]\`);
      cy.checkErrorsWereDetected();\n`;
  return codeText.replace('cy.checkErrorsWereDetected();\n', clickCode);
};

const putClassClickSnippet = (codeText, classId, typeId) => {
  const clickCode = `cy.clickIfExistClass(\`[${typeId}"${classId}"]\`);
      cy.checkErrorsWereDetected();\n`;
  return codeText.replace('cy.checkErrorsWereDetected();\n', clickCode);
};

const putIdFormSnippet = (codeText, idsForm) => {
  let fillingCode = '';
  idsForm.forEach((elem) => (fillingCode += getCorrectTest(elem)));
  fillingCode += `cy.submitIfExist(\`.ant-form\`);\n
      cy.checkErrorsWereDetected();\n`;

  return codeText.replace('cy.checkErrorsWereDetected();\n', fillingCode);
};

const getCorrectTest = (element) => {
  const insideInput = element.isInsideInput ? ' input' : '';
  if (!element.classId || element.classId === 'input') {
    return `cy.fillInput(\`[${element.typeId}"${element.id}"]${insideInput}\`, \`${faker.random.word().replace(/[^\w\s]/gi, '')}\`);\n`;
  } else if (element.classId === 'input-cpf') {
    return `cy.fillInput(\`[${element.typeId}"${element.id}"]${insideInput}\`, \`${faker.br.cpf({
      format: true,
    })}\`);\n`;
  } else if (element.classId === 'input-cnpj') {
    return `cy.fillInput(\`[${element.typeId}"${element.id}"]${insideInput}\`, \`${faker.br.cnpj({
      format: true,
    })}\`);\n`;
  } else if (element.classId === 'input-number') {
    return `cy.fillInput(\`[${element.typeId}"${element.id}"]${insideInput}\`, \`${faker.random.number({
      min: 1,
      max: 10,
    })}\`);\n`;
  } else if (element.classId === 'input-big-decimal' || element.classId === 'input-monetary') {
    return `cy.fillInput(\`[${element.typeId}"${element.id}"]${insideInput}\`, \`${faker.random
      .float({
        min: 1,
        max: 10,
      })
      .toString()
      .replace('.', ',')}\`);\n`;
  } else if (element.classId === 'input-power-search') {
    return `cy.fillInputPowerSearch(\`[${element.typeId}"${element.id}"]${insideInput}\`);\n`;
  } else if (element.classId === 'input-power-select') {
    return `cy.fillInputPowerSelect(\`[${element.typeId}"${element.id}"]${insideInput}\`);\n`;
  } else if (element.classId === 'input-select' || element.classId === 'input-select-multiple') {
    return `cy.fillInputSelect(\`[${element.typeId}"${element.id}"]${insideInput}\`);\n`;
  } else if (element.classId === 'input-checkbox' || element.classId === 'input-radio') {
    return `cy.fillInputCheckboxOrRadio(\`[${element.typeId}"${element.id}"]${insideInput}\`);\n`;
  } else if (element.classId === 'input-picker' || element.classId === 'input-month-picker' || element.classId === 'input-range-picker') {
    return `cy.clickIfExist('[${element.typeId}"${element.id}"]');\n`;
  } else if (element.classId === 'input-submit') {
    return `cy.clickIfExist('[${element.typeId}"${element.id}"]');\n`;
  }
};

module.exports = {
  generateNewTestCodes,
};
