requireUncached = (module) => {
  delete require.cache[require.resolve(module)];
  return require(module);
};
const fs = requireUncached('fs');
const { execSync } = require('child_process');
const util = require('./util');
const generate = require('./generate');
const path_project = require('path');

const baseUrl = process.env.BASE_URL;
const e2eFolder = process.env.E2E_FOLDER || '../e2e/exploratory';
const fileTestName = 'cytestion.spec.js';

const generateCode = () => {
  const pathToTmp = '../tmp/';
  const fileTestFinal = `${e2eFolder}/${fileTestName}`;
  const fileTestTmp = `${e2eFolder}/tmp/${fileTestName}`;

  if (!fs.existsSync(fileTestTmp)) {
    fs.mkdirSync(`${e2eFolder}/tmp/`, { recursive: true });
    const executionMode = process.env.EXECUTION_MODE;
    let rootFile;
    if (executionMode === 'production') {
      rootFile = util.getRootTestFileProd();
    } else {
      rootFile = util.getRootTestFile();
    }
    fs.writeFileSync(fileTestTmp, rootFile);
    fs.writeFileSync(`${path_project.resolve(__dirname, pathToTmp)}/translate.json`, JSON.stringify({}));
  } else {
    const contentTestFile = fs.readFileSync(fileTestTmp).toString();
    const codeList = contentTestFile.split('//--CODE--');

    const header = codeList.shift();
    const footer = codeList.pop();

    let codeListProcessed = util.dataProcessor(codeList);

    let filesTmp = fs.readdirSync(path_project.resolve(__dirname, pathToTmp)).filter((file) => file !== '.gitignore');

    let filesTmpRead = util.readTmpFiles(codeListProcessed, filesTmp);
    filesTmpRead = util.filterFilesByBaseUrl(baseUrl, filesTmpRead);

    let newCodes = [];
    codeListProcessed.forEach((code) => {
      if (util.canContinue(code, filesTmpRead)) {
        const actualFile = filesTmpRead.find((file) => file.name === code.actualId.join('->'));

        if (actualFile) {
          generate.generateNewTestCodes(code, actualFile, codeListProcessed, newCodes);
        }
      }
    });

    if (newCodes.length > 0) {
      //generate new tests
      util.putSkipInTests(codeListProcessed);
      let result = [];
      result.push(header);
      result.push(...codeListProcessed.map((elem) => elem.codeText));
      result.push(...newCodes);
      result.push(footer);
      fs.writeFileSync(fileTestTmp, result.join('//--CODE--'));
    } else {
      //clear final tests
      if (filesTmp.length > 0) {
        execSync(`rm -v ${path_project.resolve(__dirname, pathToTmp)}/*`);
      }
      let result = [];
      const codeListProcessedFiltered = util.filterAndClearCodeList(codeListProcessed);
      result.push(header);
      result.push(...codeListProcessedFiltered.map((elem) => elem.codeText));
      result.push('\n});');
      execSync(`rm -R ${e2eFolder}/tmp`);
      fs.writeFileSync(fileTestFinal, result.join(''));
      execSync(`yarn format-file ${fileTestFinal}`, { stdio: 'pipe' });
    }
  }
};

generateCode();
