const fs = require('fs');
const path_project = require('path');
const ahocorasick = require('ahocorasick');
let rawdata = fs.readFileSync(path_project.resolve(__dirname, '../data/ant-design/identifiers.json'));
const identifiers = JSON.parse(rawdata).identifiers;
const ac = new ahocorasick(identifiers);

rawdata = fs.readFileSync(path_project.resolve(__dirname, '../data/ant-design/dictionary.json'));
const json = JSON.parse(rawdata);
const keysData = Object.keys(json);
// although defined here, the states of these attributes are not stored between generations
const tagsObject = { testCaseNames: [] };
const tagsPure = {};
let generation = 0;

const searchContent = (obj, getIdByIdx, getTagOfIdx, extractTwoTagsAbove, extractUrl) => {
  const listResult = ac.search(obj.content);

  let idStrings = listResult.map((elem) => {
    const newObj = {};
    newObj.id = getIdByIdx(obj.content, elem[0]);
    newObj.tag = getTagOfIdx(obj.content, elem[0]);
    newObj.twoTagsAbove = extractTwoTagsAbove(obj.content, elem[0]);
    newObj.typeId = elem[1][0];
    // just to archive data of exploration
    catalogTags(obj.name, newObj.tag, extractUrl(obj));
    catalogTagsPure(obj.name, newObj.tag, extractUrl(obj));
    return newObj;
  });

  //remove duplicates and make priority
  let idStringUnique = [];
  idStrings.forEach((curr) => {
    const bestId = identifiers.find((id) => {
      return idStrings.some((elem) => elem.tag === curr.tag && elem.typeId === id);
    });
    if (!idStringUnique.find((elem) => elem.tag === bestId.tag)) {
      idStringUnique.push(curr);
    }
  });

  obj.idClick = [];
  obj.idsForm = [];
  obj.classClick = [];

  idStringUnique.forEach((elem) => {
    if (elem.typeId === 'class=') {
      obj.classClick.push(elem);
    } else {
      const idxInput = elem.tag.indexOf('<input');
      const idxTextarea = elem.tag.indexOf('<textarea');
      const idxSelect = elem.tag.indexOf('<select');
      if (idxInput !== -1 || idxTextarea !== -1 || idxSelect !== -1) {
        if (idxInput !== 0 && idxTextarea !== 0) {
          elem.isInsideInput = true;
        }
        processTypeForm(elem, obj, getIdByIdx);
      } else {
        obj.idClick.push(elem);
      }
    }
  });
};

// just to archive data of exploration, going to be deleted
const catalogTagsPure = (testCaseName, tag, url) => {
  if (!fs.existsSync('cypress/fixtures')) fs.mkdirSync('cypress/fixtures');
  let exist = false;
  Object.keys(tagsPure).forEach((caseName) => {
    if (tagsPure[caseName]?.find((tagStr) => tagStr.split('$$')[0] === tag)) {
      exist = true;
    }
  });
  if (!exist) {
    const tagWithUrl = tag + '$$' + url;
    tagsPure[testCaseName] ? tagsPure[testCaseName].push(tagWithUrl) : (tagsPure[testCaseName] = [tagWithUrl]);
    fs.writeFileSync(`cypress/fixtures/tags-catalog-pure-${generation}.json`, JSON.stringify(tagsPure, null, 2).replace(/\\"/g, "'").replace(/=''/g, ''));
    generation = (testCaseName.match(/->/g) || []).length;
  }
};

// just to archive data of exploration, going to be deleted
const catalogTags = (testCaseName, tag, url) => {
  if (!fs.existsSync('cypress/fixtures')) fs.mkdirSync('cypress/fixtures');
  const getTagAttributes = (openingTag) => {
    const allAttributes = tag.replace(openingTag, '').split('>')[0].split('" ');

    const attributesObject = {};
    allAttributes.forEach((attribute) => {
      const firstEqualSign = attribute.indexOf('=');
      const name = attribute.substring(0, firstEqualSign);
      const value = attribute.substring(firstEqualSign + 2, attribute.length);
      attributesObject[name] = value.replace(/"/g, '');
    });
    return attributesObject;
  };

  const parentTag = tag.match(/<*(\w+)\s/);
  const openingTag = parentTag[0];
  const attributes = getTagAttributes(openingTag);

  const tagWasCatalogued = tagsObject[openingTag] != undefined;
  if (!tagWasCatalogued) {
    tagsObject[openingTag] = {};
  }
  Object.keys(attributes).forEach((attributeName) => {
    const attributeWasCatalogued = tagsObject[openingTag][attributeName] != undefined;
    if (!attributeWasCatalogued) {
      tagsObject[openingTag][attributeName] = [attributes[attributeName]];
    } else {
      if (!tagsObject[openingTag][attributeName].includes(attributes[attributeName])) {
        tagsObject[openingTag][attributeName].push(attributes[attributeName]);
      }
    }
  });
  tagsObject[openingTag]['url'] != undefined && !tagsObject[openingTag]['url'].includes(url) ? tagsObject[openingTag]['url'].push(url) : (tagsObject[openingTag]['url'] = [url]);

  fs.writeFileSync(`cypress/fixtures/tags-catalog-${generation}.json`, JSON.stringify(tagsObject, null, 2).replace(/\\"/g, "'"));
  generation = (testCaseName.match(/->/g) || []).length;
};

const processTypeForm = (elem, obj, getIdByIdx) => {
  let key;
  let idxClass;
  let actualTag = elem.tag;
  const typeString = 'type=';
  const idxType = elem.tag.indexOf(typeString);
  if (elem.tag.includes('<select')) {
    elem.classId = 'input-select';
  } else if (idxType !== -1) {
    const typeInput = getIdByIdx(elem.tag, idxType);
    if (typeInput === 'date') {
      elem.classId = 'input-picker';
    } else if (typeInput === 'number') {
      elem.classId = 'input-number';
    } else if (typeInput === 'submit') {
      elem.classId = 'input-submit';
    } else {
      elem.classId = 'input';
    }
  } else {
    const classString = 'class=';
    while (!key && idxClass !== -1) {
      idxClass = actualTag.indexOf(classString);
      if (idxClass !== -1) {
        const classInput = getIdByIdx(actualTag, idxClass);
        key = keysData.find((key) => classInput.includes(key));
        if (key) elem.classId = json[key];
        if (elem.classId === 'input') {
          if (elem.id.includes('input-cpf')) elem.classId = 'input-cpf';
          if (elem.id.includes('input-cnpj')) elem.classId = 'input-cnpj';
        }
        if (!key) {
          actualTag = actualTag.substr(idxClass + classString.length);
        }
      } else {
        key = keysData.find((key) => elem.twoTagsAbove.includes(key));
        if (key) elem.classId = json[key];
        else elem.classId = 'input';
      }
    }
  }
  obj.idsForm.push(elem);
};

module.exports = {
  searchContent,
};
