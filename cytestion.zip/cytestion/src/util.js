const fs = require('fs');
const path_project = require('path');
const search = require('./search');

const getPosition = (string, subString, index) => {
  return string.split(subString, index).join(subString).length;
};

const getContentBetween = (string, begin, end) => {
  let cutString = string.substring(string.indexOf(begin) + begin.length);
  cutString = cutString.substring(0, cutString.indexOf(end));
  return cutString;
};

const getIdByIdx = (string, idx) => {
  let cutString = string.substr(idx);
  cutString = cutString.substring(cutString.indexOf('"') + 1);
  cutString = cutString.substring(0, cutString.indexOf('"'));
  return cutString;
};

const getTagOfIdx = (string, idx) => {
  let cutString = string.substring(string.lastIndexOf('<', idx));
  const tagName = cutString.substring(0, cutString.indexOf(' '));
  const closeTag = tagName.replace('<', '</');
  const idxCloseTag = cutString.indexOf(closeTag);
  if (idxCloseTag !== -1) {
    const tempCutString = cutString.substring(0, idxCloseTag + closeTag.length + 1);
    const countNameTag = (tempCutString.match(new RegExp(tagName, 'g')) || []).length;
    if (countNameTag > 1) {
      return cutString.substring(0, getPosition(cutString, closeTag, countNameTag) + closeTag.length + 1);
    } else {
      return tempCutString;
    }
  } else {
    cutString = cutString.substring(0, cutString.indexOf('>') + 1);
  }
  return cutString;
};

const extractTwoTagsAbove = (string, idx) => {
  let cutString = string.substring(0, string.lastIndexOf('<', idx) - 1);
  cutString = cutString.substring(0, cutString.lastIndexOf('<', idx) - 1);
  return string.substring(cutString.lastIndexOf('<', idx), string.lastIndexOf('<', idx));
};

const getRootTestFile = () => {
  const pathToBaseTest = '../data/base-files/cytestion-base.spec.js';
  return fs.readFileSync(path_project.resolve(__dirname, pathToBaseTest)).toString();
};

const getRootTestFileProd = () => {
  const pathToBaseTest = '../data/base-files/cytestion-base-prod.spec.js';
  return fs.readFileSync(path_project.resolve(__dirname, pathToBaseTest)).toString();
};

const dataProcessor = (codeList) => {
  return codeList.map((elem) => {
    const obj = {};
    obj.codeText = elem;
    obj.actualId = getContentBetween(elem, 'const actualId = [`', '`];').replace(/`/g, '').split(',');
    return obj;
  });
};

const readTmpFiles = (codeList, filesTmp) => {
  const result = [];
  const pathToTmp = '../tmp/';
  const rawdata = fs.readFileSync(`${path_project.resolve(__dirname, pathToTmp)}/translate.json`);
  const translate = JSON.parse(rawdata);
  const filteredFilesTmp = filesTmp.filter((file) => codeList.map((elem) => elem.actualId.join('->')).includes(translate[file]));
  filteredFilesTmp.forEach((file) => {
    const obj = {};
    obj.name = translate[file];
    obj.content = fs.readFileSync(path_project.resolve(__dirname, pathToTmp) + '/' + file).toString();

    search.searchContent(obj, getIdByIdx, getTagOfIdx, extractTwoTagsAbove, extractUrl);
    result.push(obj);
  });
  return result;
};

const extractUrl = (file) => {
  const start = file.content.indexOf('$$') + 2;
  const end = file.content.lastIndexOf('$$');
  return file.content.substring(start, end);
};

const filterFilesByBaseUrl = (baseUrl, filesTmp) => {
  const filteredFiles = filesTmp.filter((file) => {
    const url = extractUrl(file);
    return url.includes(baseUrl);
  });
  return filteredFiles;
};

const canContinue = (code, filesTmp) => {
  if (code.codeText.includes('skip')) return false;

  const actualFile = filesTmp.find((file) => file.name === code.actualId.join('->'));
  const parentFile = filesTmp.find((file) => file.name === code.actualId.filter((el, idx) => idx < code.actualId.length - 1).join('->'));

  if (actualFile && parentFile) {
    if (actualFile.content === parentFile.content) return false;
  }
  return true;
};

const willNotGenerateDuplicate = (actualString, actualId, codes, newCodes) => {
  const actualIdWithoutVariant = actualId.replace(/rc-tabs-[0-9]+/g, '');
  const actualStringWithoutVariant = actualString.replace(/rc-tabs-[0-9]+/g, '');
  return !codes.some((code) => code.codeText.replace(/rc-tabs-[0-9]+/g, '').includes(actualIdWithoutVariant + '`];')) && !newCodes.some((code) => code.replace(/rc-tabs-[0-9]+/g, '').includes(actualStringWithoutVariant));
};

const putSkipInTests = (codeList) => {
  codeList.forEach((code) => {
    code.codeText = code.codeText.replace(/ it\(`/g, ' it.skip(`');
  });
};

const filterAndClearCodeList = (codeList, result = []) => {
  if (codeList.length > 0) {
    const turnCode = codeList.shift();
    const isSubset = [...result, ...codeList].some((code) => turnCode.actualId.every((id) => code.actualId.includes(id)));
    if (!isSubset) {
      turnCode.codeText = turnCode.codeText
        .replace(/ it.skip\(`/g, ' it(`')
        .replace(/cy.writeContent(actualId);\n/g, '')
        .replace(/clickIfExist/g, 'clickCauseExist')
        .replace('cy.writeContent(actualId);', '')
        .replace(/^.*const actualId = .*$\n/gm, '')
        .replace(/^\s*[\r\n]/gm, '');
      result.push(turnCode);
    }
    return filterAndClearCodeList(codeList, result);
  } else {
    return result;
  }
};

module.exports = {
  getContentBetween,
  getIdByIdx,
  getTagOfIdx,
  getRootTestFile,
  getRootTestFileProd,
  dataProcessor,
  readTmpFiles,
  filterFilesByBaseUrl,
  canContinue,
  willNotGenerateDuplicate,
  putSkipInTests,
  filterAndClearCodeList,
  extractTwoTagsAbove,
  extractUrl,
};
